#!/usr/bin/env bash
# Independent observer only: no deploy session, motion call, old-process stop or autostart.
set -euo pipefail
rp1_background_base=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
if [[ "${1:-}" != --restricted ]]; then
  exec env -u PYTHONPATH taskset --cpu-list 1-3,7 bash "$rp1_background_base/start-observer-background.sh" --restricted
fi
rp1_background_python="$rp1_background_base/.venv/bin/python"
rp1_background_launcher="$rp1_background_base/start-observer.sh"
rp1_background_log="$rp1_background_base/observer.log"
rp1_background_timeout=${RP1_OBSERVER_START_TIMEOUT:-20}
if [[ ! "$rp1_background_timeout" =~ ^[1-9][0-9]?$ ]] || (( rp1_background_timeout > 60 )); then
  echo 'RP1_OBSERVER_START_TIMEOUT须为1至60秒。' >&2
  exit 5
fi
if [[ ! -x "$rp1_background_python" || ! -f "$rp1_background_launcher" ]]; then
  echo '安装不完整：需要同目录的start-observer.sh和.venv/bin/python，未启动。' >&2
  exit 5
fi

rp1_background_check() {
  "$rp1_background_python" -B - "$@" <<'PY'
import errno
import json
import os
from pathlib import Path
import socket
import sys
import time
import urllib.error
import urllib.request

PORT = 8891
URL = 'http://127.0.0.1:8891/api/v1/factory/segments'


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def factory_ready():
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
        with opener.open(URL, timeout=1) as response:
            raw = response.read(2 * 1024 * 1024 + 1)
            if response.status != 200 or len(raw) > 2 * 1024 * 1024:
                return False
        value = json.loads(raw)
        return (isinstance(value, dict) and 'active_segment_id' in value
                and isinstance(value.get('segments'), list))
    except (OSError, ValueError, urllib.error.URLError):
        return False


def port_state():
    try:
        with socket.create_connection(('127.0.0.1', PORT), timeout=1):
            return 'occupied'
    except ConnectionRefusedError:
        return 'free'
    except OSError as exc:
        return 'free' if exc.errno == errno.ECONNREFUSED else 'unknown'


def alive(pid):
    try:
        os.kill(pid, 0)
        # A terminated child may remain visible until the parent reaps it.
        fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
        return fields[0] != 'Z'
    except (OSError, IndexError):
        return False


def owns_listener(pid):
    listening = set()
    try:
        for table in ('/proc/net/tcp', '/proc/net/tcp6'):
            path = Path(table)
            if not path.exists():
                continue
            for line in path.read_text().splitlines()[1:]:
                fields = line.split()
                if len(fields) >= 10 and fields[1].rsplit(':', 1)[-1] == f'{PORT:04X}' and fields[3] == '0A':
                    listening.add(f'socket:[{fields[9]}]')
        for descriptor in Path(f'/proc/{pid}/fd').iterdir():
            try:
                if os.readlink(descriptor) in listening:
                    return True
            except OSError:
                continue
    except OSError:
        pass
    return False


def main(arguments):
    if arguments[0] == 'probe':
        state = port_state()
        if state == 'free':
            return 0
        if state == 'unknown':
            return 23
        return 20 if factory_ready() else 21
    pid, seconds = int(arguments[1]), int(arguments[2])
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if not alive(pid):
            return 31
        if owns_listener(pid) and factory_ready() and alive(pid):
            return 0
        time.sleep(.2)
    return 32


if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1:]))
PY
}

rp1_background_print_checks() {
  printf '本安装日志：%s\n' "$rp1_background_log"
  printf '%s\n' '后续只读检查（在机器人终端执行）：' \
    'curl --max-time 5 -sS http://127.0.0.1:8891/api/v1/state' \
    'curl --max-time 5 -sS -i http://127.0.0.1:8891/api/v1/factory/segments'
}

exec 8>"$rp1_background_base/observer-background.lock"
if ! flock --nonblock 8; then
  echo '另一个后台启动请求正在核对，未启动第二份；请稍后只读检查。' >&2
  rp1_background_print_checks
  exit 4
fi
if rp1_background_check probe; then
  :
else
  rp1_background_status=$?
  rp1_background_print_checks
  case "$rp1_background_status" in
    20)
      echo '8891已有支持工厂接口的监听，未启动第二份；未认定它属于本安装。'
      exit 2
      ;;
    21)
      echo '8891已被旧版或其他服务占用，未启动、未停止原进程；请先核对其身份及版本。' >&2
      exit 3
      ;;
    *)
      echo '无法可靠核对8891状态，未启动；请检查本安装的Python及本机网络权限。' >&2
      exit 5
      ;;
  esac
fi

# Redirect every standard descriptor and close the helper lock in the child.
# The original launcher keeps the CPU/ROS/identity/observer-lock checks.
nohup env -u PYTHONPATH bash "$rp1_background_launcher" \
  >> "$rp1_background_log" 2>&1 < /dev/null 8>&- &
rp1_background_pid=$!
if rp1_background_check wait "$rp1_background_pid" "$rp1_background_timeout"; then
  printf '本次observer已独立后台启动并核对工厂接口，PID=%s。\n' "$rp1_background_pid"
  echo '可退出SSH；这不是开机自启，机器人重启后仍须重新启动。未启停运控或策略。'
  rp1_background_print_checks
else
  rp1_background_print_checks
  echo '启动请求已发出，但未确认该进程成功提供工厂接口；可能已退出或仍在启动。' >&2
  echo '原进程和数据未被自动停止或删除。请查看日志并核对，勿根据本提示认定记录已经开始。' >&2
  exit 5
fi
